# pixelpartitioner
 The package, designed for advanced image analysis, provides tools for pixel partitioning, intensity-based segmentation, and visualization. It includes functions for multi-class OTSU thresholding to classify pixel intensities into distinct regions, analyze pixel distribution, and highlight specific areas of interest within images. 
